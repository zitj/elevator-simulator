export class Floor {
	constructor(id) {
		this.id = id;
	}
}
