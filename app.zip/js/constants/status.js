const STATUS = {
	IDLE: 'idle',
	MOVING_UP: 'moving UP',
	MOVING_DOWN: 'moving DOWN',
	READY: 'READY',
};

export { STATUS };
