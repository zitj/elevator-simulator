import { Elevator } from '../classes/elevator.js';
import { elevators } from '../../app.js';
import { elevatorsDOM, floorsDOM } from '../DOM/dom-elements.js';

export let distanceBetweenElevators = 0;

function resetDistance() {
	distanceBetweenElevators = 0;
}

function setCoordinatesToElevator(elevator, htmlElement, numberOfElevators) {
	const { x, y } = floorsDOM.childNodes[elevator.currentFloor].getBoundingClientRect();
	const floorWidth = floorsDOM.childNodes[elevator.currentFloor].getBoundingClientRect().width;
	let initialX = htmlElement.getBoundingClientRect().x;
	let initialY = htmlElement.getBoundingClientRect().y;
	let divider = 2;
	console.log(floorWidth / numberOfElevators / 2);
	if (numberOfElevators * 40 + numberOfElevators * (floorWidth / numberOfElevators / divider)) divider = 4;
	distanceBetweenElevators += htmlElement.getBoundingClientRect().width + floorWidth / numberOfElevators / divider;
	elevator.coordinates = { initial: { x: initialX, y: initialY }, floor: { x, y } };
	elevator.coordinates.initial = { x: distanceBetweenElevators, y: initialY };
	elevator.coordinates.floor = { x, y: y - 9 };
	htmlElement.style.position = 'absolute';
	console.log('Initial distance: ', distanceBetweenElevators);
	htmlElement.style.left = `${elevator.coordinates.initial.x + 10}px`;
	htmlElement.style.top = `${elevator.coordinates.floor.y}px`;
	htmlElement.dataset.id = elevator.id;
	htmlElement.innerHTML = `<span>${elevator.id + 1}</span>`;
}

function renderElevatorsDOM(elevator, numberOfElevators) {
	let elevatorHTMLelement = document.createElement('div');
	elevatorHTMLelement.classList.add('elevator');
	elevatorsDOM.appendChild(elevatorHTMLelement);
	setCoordinatesToElevator(elevator, elevatorHTMLelement, numberOfElevators);
}

function generateElevators(numberOfElevators) {
	if (numberOfElevators && numberOfElevators > 0) {
		for (let i = 0; i < numberOfElevators; i++) {
			let elevator = new Elevator(i, 'idle', 0, null);
			elevators.push(elevator);
			renderElevatorsDOM(elevator, numberOfElevators);
		}
		// console.log(`There are ${numberOfElevators} elevators in this building: `, elevators);
	} else {
		console.log(`There are no elevetors inside this building, you will have to take stairs. :)`);
	}
}

export { generateElevators, resetDistance };
