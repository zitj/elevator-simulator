export const SYMBOLS = {
	ARROW_UP: '&#8679;',
	ARROW_DOWN: '&#8681;',
	PERSON: '🧍🏻‍♂️',
	PASSANGERS: {
		0: '🧍🏻‍♂️',
		1: '🧍🏽‍♀️',
		2: '🧍',
		3: '⛹🏿‍♂️',
		4: '💃',
		5: '🕴️',
		6: '👫',
	},
};
