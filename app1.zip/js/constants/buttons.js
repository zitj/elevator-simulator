export const BUTTONS = {
	START: 'START',
	STOP: 'STOP',
};
