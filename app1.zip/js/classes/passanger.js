export class Passanger {
	constructor(id, waitingOnFloorNumber, waitingForElevator) {
		this.id = id;
		this.waitingOnFloorNumber = waitingOnFloorNumber;
		this.waitingForElevator = waitingForElevator;
	}
}
