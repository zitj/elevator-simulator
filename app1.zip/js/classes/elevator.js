export class Elevator {
	constructor(id, status, currentFloor, coordinates, destinationFloor) {
		this.id = id;
		this.status = status;
		this.currentFloor = currentFloor;
		this.coordinates = coordinates;
		this.destinationFloor = destinationFloor;
	}
}
